Barren – is the easiest and most powerful online event booking and ticketing system. Easiest way to sell your event tickets online. Barren's provides an industry-leading platform with customizable ticketing features and built-in event promotion tools. Barren's is absolutely free for free events.

Meet Barren, a fully-featured HTML template for Simple Online Event Ticketing System, We just released the fully coded version in HTML, CSS, JS. If you are looking for any type of Event Booking then Barren is the best Simple Online Event Ticketing System Bootstrap 5 Template to create your website.

Features :-

- 43 Html Files
- Latest Bootstrap 5.1.3
- Latest jQuery 3.6.0
- 2 in 1 – light, dark
- Responsive layouts
- HTML 5 and CSS 3
- CSS 3 animation
- W3C valid HTML files
- Integrated with FontAwesome, Unicons, Flaticons
- Bootstrap components compatible
- Organisation Dashboard
- Organiser Profile
- Attendee Profile
- Pricing
- Well and commented code
- Item support
- Easy Customizable
- Professional Support
- Life Time Free Update
- Creative and unique design
- Pixel perfect
- Free Google Fonts
- Free Font Awesome Icons
- Free Unicons Icons
- Free Svg Based Icons


Fonts used :-

Roboto: https://fonts.google.com/specimen/Roboto


Icon Used :-

Unicons: https://iconscout.com/unicons/
FontAwesome: https://fontawesome.com/
Flaticons: https://www.flaticon.com/

IMPORTANT!!! All Images are from different resources and they are not included to Html files.


Pixel Dimensions: 1920x3500

Tags:  Events, Sell Tickets, bootstrap 5, Venue, Webiner, Talk Show, Online Class, Party, Online Events, Venue Events, Hosting, Organiser, Ticketing System, Attendees, Organisation Dashboard